import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;
import java.util.*;
import java.io.*;
import java.nio.file.Files;
import static java.nio.file.StandardCopyOption.*;

public class Assig4{

private static JFrame _frame;
private static JButton _loginButton;
private static JButton _castVoteButton;
private static JFrame _loginFrame;
private static JLabel _loginLabel;
private static JTextField _loginID;
private static JButton _loginIDButton;
private static ArrayList<Ballot> ballots = null;
private static ArrayList<Voter> voters = null;
private static int id = 0;
	
	public Assignment4(String st) throws IOException{
		// accepts ballot file from command line
		File f = new File(st); 
		Scanner sc = new Scanner(f);
		
		if (f.exists()) {
			int ballotsOffered = sc.nextInt();
			sc.nextLine();
			ballots = new ArrayList<Ballot>(ballotsOffered);
			while (sc.hasNextLine()) {
			// reads in ballots and candidates
				String option = sc.nextLine();
				ballots.add(new Ballot(option));
			}
		} 
		else {
			System.out.println("File does not exist.");
		}
		sc.close();
		// creates new frame for voter program
		_frame = new JFrame("E-Voter Version 1.0");
		_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		_frame.setLayout(new FlowLayout());
		
		//creates Login and Cast Vote Buttons on _frame
		ActionListener openLoginFrame = new LoginButtonListener();
		_loginButton = new JButton("Login");
		_loginButton.addActionListener(openLoginFrame);
		_castVoteButton =  new JButton("Cast Vote");
		_castVoteButton.setEnabled(false);
		_castVoteButton.addActionListener(openLoginFrame);

		// adds ballot panels and buttons to frame
		for (Ballot b: ballots) {
			_frame.add(b);
		}
		_frame.add(_loginButton);
		_frame.add(_castVoteButton);
		
		// automatically sets the size of the window to fit the components
		_frame.pack();

		// Finally make it all visible
		_frame.setVisible(true);
	}

	public static void main (String [] args) throws IOException{
		// starts voter program
		new Assignment4(args[0]);
	}
	
	private class LoginButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
		// performs actions for login button pressed
			if (e.getSource() == _loginButton) {
				try {
				String userID = JOptionPane.showInputDialog("Please enter usename: ");
				id = Integer.parseInt(userID);
				System.out.println("Input id is "+id);
				File fi = new File("voters.txt");
				Scanner scan = new Scanner(fi);
				voters = new ArrayList<Voter>(5);
					if (fi.exists()) {
						while (scan.hasNextLine()) {
							// looks through and saves voters  
							String option2 = scan.nextLine();
							voters.add(new Voter(option2));
						}
						//looks to see if voter has a registered ID
						for (Voter v: voters){
							System.out.println("Reading ArrayList for registered voters");
							int voterID = v.getId();
							if (voterID == id) {
							//check to see if they've already voted 
							System.out.println("Comparing voter ID ints");
									if (v.getVoterStatus().equals("false")) {
										System.out.println("Comparing voter status");
										//enables all the buttons and disables login
										String tempName = v.getVoterName()+ " you may now vote!";
										JOptionPane.showMessageDialog(_frame,tempName, "Welcome",JOptionPane.PLAIN_MESSAGE);
										for (Ballot b: ballots) {
											b.enableButtons();
										}
										_castVoteButton.setEnabled(true);
										_loginButton.setEnabled(false);
										break;
									}
									else {
										JOptionPane.showMessageDialog(_frame,"You have already voted!", "Error",JOptionPane.ERROR_MESSAGE);
									}
							}
							else {
								break;
							}
						}
					} 
				}
				catch (FileNotFoundException eed) {
					JOptionPane.showMessageDialog(_frame,"Please acquire voters.txt to continue.", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		//performs different action for cast vote button pressed
			else if (e.getSource() == _castVoteButton) {
				//cast vote
				int input = JOptionPane.showConfirmDialog(_frame,"Is this your final decision?","Cast Vote",JOptionPane.OK_CANCEL_OPTION);
				System.out.println(input);
				if (input == 0) {
					//changes voter status to true (aka logs that they've voted)
						for (Voter vot: voters) {
							int voterID = vot.getId();
							if (id == voterID) {
								System.out.println("changing voter Status");
								vot.changeVoterStatus();
							}
						}
					//safe save voter file
					try {
						PrintWriter voterOut = new PrintWriter("voters.txt");
						for (Voter vote: voters) {
							voterOut.println(vote.toString());
						}
						voterOut.close();
					}
					catch (Exception eede) {
						//do nothing
					}
				}
				else {
					//do nothing, return to voting
				}
				input = JOptionPane.showConfirmDialog(_frame,"Next Voter?","Cast Vote",JOptionPane.OK_CANCEL_OPTION);
				if (input == 0) {
					//restarts voting process
					_castVoteButton.setEnabled(false);
					_loginButton.setEnabled(true);
					for (Ballot b: ballots) {
						b.disableButtons();
					}
				}
				else {
				 //does nothing
				}
			}
			else {
				JOptionPane.showMessageDialog(_frame,"What sorcery is this?", "GASP",JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
}

