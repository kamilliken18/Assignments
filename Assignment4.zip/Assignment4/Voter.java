import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;

public class Voter {
private String st, name;
private int id;
private String voted;
private String[] voterIDs;
	
	public Voter(String option){
		st = option; 
		voterIDs = st.split(":");
		String tempId = voterIDs[0];
		id = Integer.parseInt(tempId);
		name = voterIDs[1];
		voted = voterIDs[2];
	}
	public int getId(){
		System.out.println("Voter ID is "+id);
		return id; 
	}
	public String getVoterStatus(){
		return voted;
	}
	public void changeVoterStatus() {
		voted = "true";
	}
	public String getVoterName(){
		return name;
	}
	public String toString() {
		String voterInfo = id+":"+name+":"+voted;
		return voterInfo;
	}
}