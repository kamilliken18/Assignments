import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;
import java.util.*;
import java.io.*;

public class Ballot  extends JPanel{
	/*Contains all data for the ballot, 
	the buttons for selecting candidates to office 
	and ActionListener to respond to candidate choices */  
private String st, id, categoryTitle, candidates; 
private String[] categories;
private String[] candidateOptions;
private ArrayList<JButton> btns;
private JLabel _ballotTitle;
private int numRows = 1;
public ButtonListener buttonToggle = new ButtonListener();

	public Ballot(String option){
		st = option; //sets each ballot from main to a string variable
		categories = st.split(":");
		id = categories[0];
		categoryTitle = categories[1];
		candidates = categories[2]; 
		candidateOptions = candidates.split(",");
		numRows += (candidateOptions.length);
		btns = new ArrayList<JButton>();
		
		this.setLayout(new GridLayout(numRows,1));
		//labels the ballot with the category title
		_ballotTitle = new JLabel();
		_ballotTitle.setText(categoryTitle);
		_ballotTitle.setFont(new Font("CourierNew", Font.PLAIN, 24));
		_ballotTitle.setHorizontalAlignment(SwingConstants.CENTER);
		this.add(_ballotTitle);
		
		//adds all the buttons for each ballot
		for(int i=0; i < candidateOptions.length; i++) {
			btns.add(new JButton(candidateOptions[i]));
		}
		//adds actionListener for each button and disables on open
		for (JButton b: btns) {
			b.addActionListener(buttonToggle);
			b.setEnabled(false);

		}
		//adds buttons to Ballot Panel
		for (int j = 0; j < candidateOptions.length; j++) {
			this.add(btns.get(j));
 		}
	//makes Ballot Panel visible
	setVisible(true);
	}
	//returns Ballot ID
	public String getId(){
		return id; 
	}
	//enables buttons after user logs in
	public void enableButtons(){
		for (JButton b: btns) {
			b.setEnabled(true);
		}
	}
	public void disableButtons(){
		for (JButton b: btns) {
			b.setEnabled(false);
		}
	}
	private String _selectedText = "";
	// Debug message to console
	public void setSelectedText(String text) {
		System.out.println("For ballot ID: " + id + ", selected " + text);
		_selectedText = text;
	}
	// gets button text 
	public String getSelectedText() {
		return _selectedText;
	}
	
	// return each ballot and then each cand for each ballot (loop through each ) 
	class ButtonListener implements ActionListener {

    // Every time we click the button, it will perform
    // the following action.
		public void actionPerformed(ActionEvent e) {
			String actionCommand = e.getActionCommand();
			JButton b = (JButton) e.getSource();
			String buttonSelectedText = b.getText();
			setSelectedText(buttonSelectedText);
			// selects button and changes color of font to red
			for (JButton but: btns) {
				if (but.getText().equals(actionCommand)){
					but.setForeground(Color.GREEN);
				}
				else {
					but.setForeground(Color.BLACK);
				}
			}
		}
	}
}
